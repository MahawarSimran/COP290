# Maze-Game
## Install these SDL libraries on Linux:
1. sdl2  

2. sdl image  

3. sdl mixer  

## How to run the game:

1. Clone this repository  or download as Zip and extract.
2. Run the `make` command. 
3. This will create an executable name "game" .
4. Now run the `./game` command.


## Online resources used:
https://lazyfoo.net/tutorials/SDL/index.php
https://github.com/schuay/pacman
https://gist.github.com/BoredBored/3187339a99f7786c25075d4d9c80fad5
