This yourcode.cpp file has all the functions of subtask 1.
eval folder has all testcases and their outputs.
After running the code all output files get stored in output folder.
To run this code just type make.

	
After this output file will  be created.
