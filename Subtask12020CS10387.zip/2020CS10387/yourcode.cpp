#include <iostream>
#include <cmath>
#include <fstream>
#include <string>
#include <vector>
using namespace std;
float sigm(float x){
    float a;
    a = exp(-x);
    return 1.0/(a+1.0);
}
float ttanh(float x){
    float a;
    a = exp(2*x);
    return (a-1)/(a+1);
}
void matrix(string input,string weight,string bias,string output){
    int n,m,a,b,c,d;
    fstream newfile;
    newfile.open(weight,ios::in); //open a file to perform read operation using file object
    if (newfile.is_open()){   //checking whether the file is open
        float tp;
        if(newfile >> tp){
            n = tp;
        }
        if(newfile >> tp){
            m = tp;
        }
        else{
            cout << "Incorrect Input ";
        }
        float matrix1[n][m];
        int i=0,j=0;
        while(i < n ){
            while(j < m && newfile >> tp){
                matrix1[i][j] = tp;
                j += 1;
            }
            i +=1;
            j =0;
        }
        newfile.close(); //close the file object.
        newfile.open(input,ios::in); //open a file to perform read operation using file object
   		if (newfile.is_open()){   //checking whether the file is open
      	float tp;
      	if(newfile >> tp){
         	a = tp;
      	}
      	if(newfile >> tp){
         	b = tp;
     	}
      	float matrix2[a][b];
     	int i=0,j=0;
      	while(i < a ){
        	while(j < b && newfile >> tp){
            	matrix2[i][j] = tp;
            	j += 1;
         	}
         	i +=1;
         	j =0;
      	}
      	newfile.close(); //close the file object.
  	  	newfile.open(bias,ios::in); //open a file to perform read operation using file object
	  		if (newfile.is_open()){   //checking whether the file is open
      	  		float tp;
      	  		
          		if(newfile >> tp){
      	   			c = tp;
      			}
  			    if(newfile >> tp){
      			    d = tp;
      			}
      			float matrix3[c][d];
      			int i=0,j=0;
    			while(i < c ){
        			while(j < d && newfile >> tp){
           				matrix3[i][j] = tp;
            				j += 1;
         			}
         			i +=1;
         			j =0;
      			}
      			if(c!=n || d!=b || a!= m){
          			cout << "Incorrect Input ";
      			}
      			newfile.close();
      			newfile.open(output,ios::out);  // open a file to perform write operation using file object
      			if(newfile.is_open()){
      				newfile <<n << "\n";   //inserting text
      				newfile <<b << "\n";
      				float final[n][b];
      				i =0,j=0;
      				while(i < n){
         				while( j < b){
         				final[i][j] =0;
            				for(int k = 0; k < m; k++){
              				    final[i][j] += matrix1[i][k] * matrix2[k][j];
            				}
            				final[i][j] += matrix3[i][j];
            				newfile << final[i][j] << "\n";
            				j+=1;
         				}
        				i+=1;
         				j=0;
      				}
      				newfile.close();    //close the file object
      			}
   			}
        }
    }
}
void relu(string input, string output){
    int n,m;
    fstream newfile;
    newfile.open(input,ios::in); 
    if (newfile.is_open()){  
        float tp;
        if(newfile >> tp){
            n = tp;
        }
        if(newfile >> tp){
            m = tp;
        }
        else{
            cout << "Incorrect Input ";
        }
        float matrix1[n][m];
        int i=0,j=0;
        while(i < n){
            while(j < m && newfile >> tp){
                matrix1[i][j] = tp;
                j += 1;
            }
            i +=1;
            j =0;
        }
        newfile.close(); 
    
    newfile.open(output,ios::out); 
    if(newfile.is_open()){
        newfile <<n << "\n";          
        newfile <<m << "\n";
        float final[n][m];
        int i =0,j=0;
        while(i < n){
            while( j < m){
                if(matrix1[i][j] <0){
                    final[i][j] = 0.0;
                }
                else{
                    final[i][j] = matrix1[i][j];
                }
                newfile << final[i][j] << "\n";
                j+=1;
            }  
            i+=1;
            j=0;
        }
        newfile.close();    //close the file object
    }
    }

}
void tanh(string input, string output) {
    int n,m;
    fstream newfile;
    newfile.open(input,ios::in); 
    if (newfile.is_open()){  
        float tp;
        if(newfile >> tp){
            n = tp;
        }
        if(newfile >> tp){
            m = tp;
        }
        else{
            cout << "Incorrect Input ";
        }
        float matrix1[n][m];
        int i=0,j=0;
        while(i < n){
            while(j < m && newfile >> tp){
                matrix1[i][j] = tp;
                j += 1;
            }
            i +=1;
            j =0;
        }
        newfile.close(); 
    
    newfile.open(output,ios::out);  
    if(newfile.is_open()){
        newfile <<n << "\n";          
        newfile <<m << "\n";
        float final[n][m];
        int i =0,j=0;
        while(i < n){
            while( j < m){
                float z = ttanh(matrix1[i][j]);
                final[i][j] = z;
                newfile << final[i][j] << "\n";
                j+=1;
            }  
            i+=1;
            j=0;
        }
        newfile.close();    //close the file object
    }
    }

}
void maxpool(int f, string input,string output){
    int n,m;
    fstream newfile;
    newfile.open(input,ios::in); 
    if (newfile.is_open()){   
        float tp;
        if(newfile >> tp){
            n = tp;
        }
        if(newfile >> tp){
            m = tp;
        }
        else{
            cout << "Incorrect Input ";
        }
        float matrix1[n][m];
        int i=0,j=0;
        while(i < n){
            while(j < m && newfile >> tp){
                matrix1[i][j] = tp;
                j += 1;
            }
            i +=1;
            j =0;
        }
        newfile.close(); 
    
    newfile.open(output,ios::out);  
    if(newfile.is_open()){
        int a =n/f, b = m/f;
        newfile <<a<< "\n";       
        newfile <<b<< "\n";
        float final[a][b];
        int i =0,j=0;
        while(i < a){
            while( j < b){
                float maximum = -34223.0;
                for(int f1 =0;f1 < f;f1++){
                    for(int f2=0;f2 < f; f2++){
                        maximum = max(maximum,matrix1[f*i+f1][f*j+ f2]);
                    }
                }
                final[i][j] = maximum;
                newfile << final[i][j] << "\n";
                j+=1;
            }
            i+=1;
            j=0;
        }
        newfile.close();    //close the file object
    }
    }

}
void avgpool(int f,string input,string output){
    int n,m;
    fstream newfile;
    newfile.open(input,ios::in); 
    if (newfile.is_open()){   
        float tp;
        if(newfile >> tp){
            n = tp;
        }
        if(newfile >> tp){
            m = tp;
        }
        else{
            cout << "Incorrect Input ";
        }
        float matrix1[n][m];
        int i=0,j=0;
        while(i < n){
            while(j < m && newfile >> tp){
                matrix1[i][j] = tp;
                j += 1;
            }
            i +=1;
            j =0;
        }
        newfile.close(); 
    
    newfile.open(output,ios::out);  
    if(newfile.is_open()){
        int a =n/f, b = m/f;
        newfile <<a<< "\n";   //inserting text        
        newfile <<b<< "\n";
        float final[a][b];
        int i =0,j=0;
        while(i < a){
            while( j < b){
                float sum = 0.0;
                for(int f1 =0;f1 < f;f1++){
                    for(int f2=0;f2 < f; f2++){
                        sum += matrix1[f*i+f1][f*j+ f2];
                    }
                }
                final[i][j] = sum/(f*f);
                newfile << final[i][j] << "\n";
                j+=1;
            }
            i+=1;
            j=0;
        }
        newfile.close();    //close the file object
    }
    }

}
void sigmoid(string input,string output){
    int n;
    fstream newfile;
    newfile.open(input,ios::in); //open a file to perform read operation using file object
    if (newfile.is_open()){   //checking whether the file is open
        float tp;
        if(newfile >> tp){
            n = tp;
        }

        vector<float> vec;
        int i=0;
        while(i < n && newfile >> tp){
            vec.push_back(tp);
            i +=1;
        }
        newfile.close(); //close the file object.
    
    newfile.open(output,ios::out);  // open a file to perform write operation using file object
    if(newfile.is_open()){
        newfile <<n << "\n";   //inserting text        

        vector<float> final;
        int i =0;
        float sum = 0.0;
        while(i < n){
            float z = sigm(vec[i]);
            final.push_back(z);
            newfile << final[i]<< "\n";
            i+=1;
        }
        newfile.close();    //close the file object
    }
    }
}
void softmax(string input,string output){
    int n;
    fstream newfile;
    newfile.open(input,ios::in); //open a file to perform read operation using file object
    if (newfile.is_open()){   //checking whether the file is open
        float tp;
        if(newfile >> tp){
            n = tp;
        }
        else{
            cout << "Incorrect Input ";
        }
        vector<float> vec;
        int i=0;
        while(i < n && newfile >> tp){
            vec.push_back(tp);
            i +=1;
        }
        newfile.close(); //close the file object.
    
    newfile.open(output,ios::out);  // open a file to perform write operation using file object
    if(newfile.is_open()){
        newfile <<n << "\n";   //inserting text        
        vector<float> sig;
        vector<float> final;
        int i =0;
        float sum = 0.0;
        while(i < n){
            float z = exp(vec[i]);
            sig.push_back(z);
            sum += z;
            i+=1;
        }
        i =0;
        while(i < n){
            final.push_back(sig[i]/sum);
            newfile << final[i]<< "\n";
            i+=1;
        }
        newfile.close();    //close the file object
    }
    }


}
int main(int argc, char* argv[]){
try{if(argv[1]==string("fullyconnected")){
    try{
        if(argc==6){matrix(argv[2],argv[3],argv[4],argv[5]);}
        else { throw 1;}

    }
    catch(int i){cout<<"wrong number of arguments"<<endl;}
   
}
    else if(argv[1]==string("activation")){

        try{
        if (argc==5){if(argv[2]==string("relu")){
            relu(argv[3],argv[4]);
        }
        else if(argv[2]==string("tanh")){
            tanh(argv[3],argv[4]);
        }}
        else {throw 2;}}
        catch(int i){cout<<"wrong number of arguments"<<endl;}
        }
    else if(argv[1]==string("pooling")){

        try{if(argc==6){if(argv[2]==string("max")){
            maxpool(stoi(argv[4]),argv[3],argv[5]);
        }
        else if(argv[2]==string("average")){
            avgpool(stoi(argv[4]),argv[3],argv[5]);
        }}
        else{throw 3;}}
        catch(int i){cout<<"wrong number of arguments"<<endl;}
        }
    else if(argv[1]==string("probability")){

        try{if(argc==5){if(argv[2]==string("softmax")){
            softmax(argv[3],argv[4]);
        }
        else if(argv[2]==string("sigmoid")){
            sigmoid(argv[3],argv[4]);
        }}
        else{ throw 4;}}
        catch(int i){cout<<"wrong number of arguments"<<endl;}
        }
        
        else {throw 5;}}
        catch(int i){cout<<"invalid command"<<endl;}

} 

